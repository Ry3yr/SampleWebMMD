
let scene, renderer, camera, mesh, mesh2;
let mixer1, mixer2, clock, cameraAnimation;
const windowWidth = window.innerWidth;
const windowHeight = window.innerHeight;
function getQueryStringValue(key) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(key);
}
const pmx = getQueryStringValue('pmx');
const pmx2 = getQueryStringValue('pmx2');
const stage = getQueryStringValue('stage') || "/sorclair/sorclair.pmx";
let Pmx;
let Pmx2;

if (pmx) {
  Pmx = `./pmx/pronama/${pmx.trim()}`;
  console.log(`PMX: ${pmx.trim()}`);
} else {
  console.log("No PMX selected.");
}
if (pmx2) {
  Pmx2 = `./pmx/pronama/${pmx2.trim()}`;
  console.log(`PMX2: ${pmx2.trim()}`);
} else {
  console.log("No PMX2 selected.");
}
let StagePath = stage ? `./stages/${stage.trim()}` : './stages/sorclair/sorclair.pmx';
if (pmx) {
  Pmx = `./pmx/pronama/${pmx.trim()}`;console.log(`PMX: ${pmx.trim()}`);} else {console.log("No PMX selected.");}
  if (pmx2) {Pmx2 = `./pmx/pronama/${pmx2.trim()}`;console.log(`PMX2: ${pmx2.trim()}`);} else {console.log("No PMX2 selected.");}
  if (StagePath) {StagePath = `./stages${stage.trim()}`;} else {StagePath = './stages/sorclair/sorclair.pmx';}
  console.log('StagePath:', StagePath);
  if (StagePath) {
  const loader = new THREE.MMDLoader();
  const lastIndex = StagePath.lastIndexOf("/");
  const basePath = StagePath.substring(0, lastIndex);
  const vmd1Path = `${basePath}/001.vmd`;
  const vmd2Path = `${basePath}/002.vmd`;
  loader.load(StagePath, (stageObject) => {
    var ambientLight = new THREE.AmbientLight(0xffffff, 1.0); //hardcoded
    scene.add(ambientLight);
    scene.add(stageObject);
    const mixer = new THREE.AnimationMixer(stageObject);
    loader.loadAnimation(vmd1Path, stageObject, (vmd1Clip) => {
      vmd1Clip.name = "001";
      console.log(`Loaded VMD: ${vmd1Path}`);
      const motionObject1 = MotionObjects.find(obj => obj.id === "001");
      if (motionObject1) {
        motionObject1.VmdClip = vmd1Clip;
        const action1 = mixer.clipAction(vmd1Clip);
        action1.play();
      } else {
        console.warn(`Motion object with id "001" not found.`);
      }
    }, onProgress, onError);
    loader.loadAnimation(vmd2Path, stageObject, (vmd2Clip) => {
      vmd2Clip.name = "002";
      console.log(`Loaded VMD: ${vmd2Path}`);
      const motionObject2 = MotionObjects.find(obj => obj.id === "002");
      if (motionObject2) {
        motionObject2.VmdClip = vmd2Clip;
        const action2 = mixer.clipAction(vmd2Clip);
        action2.play();
      } else {
        console.warn(`Motion object with id "002" not found.`);
      }
    }, onProgress, onError);
    const clock = new THREE.Clock();
    const animate = () => {
      requestAnimationFrame(animate);
      const delta = clock.getDelta();
      mixer.update(delta);
      renderer.render(scene, camera);
    };
    animate();
  }, onProgress, onError);
} else {console.warn('No valid stage path found.');}
//if (!Stage) {Stage = stage ? `stages${stage}` : '/sorclair/sorclair.pmx';}
if (!Pmx) {Pmx = `./pmx/pronama/AoiZaizen/AoiZaizen.pmx`;}
console.log('StagePath:', StagePath);
const MotionObjects = [
  { id: "001", pose: "001", VmdClip: null, AudioClip: false },
];
window.onload = () => {
  Init();
  LoadStage().then(() => {
    LoadModels().then(() => {
    });
  });
};
function Init() {
  document.getElementById("moveLeftButton").addEventListener("click", () => { camera.position.x -= 1; });
  document.getElementById("moveRightButton").addEventListener("click", () => { camera.position.x += 1; });
  document.getElementById("moveUpButton").addEventListener("click", () => { camera.position.y += 1; });
  document.getElementById("moveDownButton").addEventListener("click", () => { camera.position.y -= 1; });
  document.getElementById("rotaterightButton").addEventListener("click", () => { mesh.rotateY(Math.PI / 4); });
  document.getElementById("rotateleftButton").addEventListener("click", () => { mesh.rotateY(-Math.PI / 4); });
  scene = new THREE.Scene();
  renderer = new THREE.WebGLRenderer({ alpha: true });
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);
  camera = new THREE.PerspectiveCamera(100, windowWidth / windowHeight, 1, 1000);
  camera.position.set(0, 19, 20);
  clock = new THREE.Clock();
}
function LoadStage() {
  return new Promise((resolve, reject) => {
    const loader = new THREE.MMDLoader();
    loader.load(StagePath, (stageObject) => {
      const ambientLight = new THREE.AmbientLight(0xffffff, 1.0);
      scene.add(ambientLight);
      resolve();
    }, onProgress, reject);
  });
}





let animate;
function startAnimation() {
  if (!animate) {
    console.error('Animation function not initialized.');
    return;
  }
  animate(); // Start the animation loop
}
document.getElementById('play').addEventListener('click', async () => {
  try {
    //await LoadModels();
    startAnimation();
  } catch (error) {
    console.error('Error loading models:', error);
  }
});
async function LoadModels() {
  const loader = new THREE.MMDLoader();
  function LoadPMX(path) {
    return new Promise(resolve => {
      loader.load(path, (object) => {
        resolve(object);
      }, onProgress, onError);
    });
  }
  async function LoadVMDAnimation(mesh, id) {
    function getQueryStringParameter(name) {
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get(name);
    }
    const vmdId = getQueryStringParameter('vmd') || id;
    const vmdPath = `./vmd/${vmdId}.vmd`;
    return new Promise((resolve, reject) => {
      loader.loadAnimation(vmdPath, mesh, (vmdClip) => {
        vmdClip.name = vmdId;
        resolve(vmdClip);
      }, onProgress, reject);
    });
  }
  async function LoadCameraAnimation(camera) {
    const cameraVmdPath = './camera/bts-bestofme.vmd';
    return new Promise((resolve, reject) => {
      loader.loadAnimation(cameraVmdPath, camera, (vmdClip) => {
        vmdClip.name = 'bts-bestofme';
        resolve(vmdClip);
      }, onProgress, reject);
    });
  }
  async function LoadModel1() {
    const mesh = await LoadPMX(Pmx);
    scene.add(mesh);
    const vmdClip = await LoadVMDAnimation(mesh, "001");
    const helper = new THREE.MMDAnimationHelper({ afterglow: 1.0 });
    const mmd = { mesh: mesh, animation: vmdClip };
    helper.add(mmd.mesh, {
      animation: mmd.animation,
      physics: true
    });
    return { mesh: mesh, helper: helper };
  }
  async function LoadModel2() {
    if (Pmx2) {
      const mesh2 = await LoadPMX(Pmx2);
      mesh2.position.x += 15;
      scene.add(mesh2);
      const vmdClip = await LoadVMDAnimation(mesh2, "002");
      const helper = new THREE.MMDAnimationHelper({ afterglow: 1.0 });
      const mmd = { mesh: mesh2, animation: vmdClip };
      helper.add(mmd.mesh, {
        animation: mmd.animation,
        physics: true
      });
      return { mesh: mesh2, helper: helper };
    }
  }

  const { mesh: mesh1, helper: helper1 } = await LoadModel1();
  const { mesh: mesh2, helper: helper2 } = await LoadModel2();

  // Load camera animation
const fov = 45; // Define the field of view
const aspect = window.innerWidth / window.innerHeight; // Define the aspect ratio
const near = 1; // Define the near clipping plane
const far = 1000; // Define the far clipping plane
  const camera = new THREE.PerspectiveCamera(fov, aspect, near, far);

  const cameraVmdClip = await LoadCameraAnimation(camera);

  // Add camera animation to the scene
  const cameraHelper = new THREE.MMDAnimationHelper();
  cameraHelper.add(camera, {
    animation: cameraVmdClip
  });

  const clock = new THREE.Clock();
  animate = () => {
    requestAnimationFrame(animate);
    const delta = clock.getDelta();
    helper1.update(delta);
    if (helper2) helper2.update(delta);
    cameraHelper.update(delta); // Update camera animation
    renderer.render(scene, camera);
  };
}

function onProgress(xhr) {
  if (xhr.lengthComputable) {
    const percentComplete = xhr.loaded / xhr.total * 100;
    console.log(Math.round(percentComplete) + '% downloaded');
  }
}

function onError(xhr) {
  console.error("Error loading resource:", xhr);
}

