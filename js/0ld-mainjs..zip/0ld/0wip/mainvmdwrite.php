<?php
// Check if the outputText parameter is present in the POST request
if (isset($_POST['outputText'])) {
  $outputText = $_POST['outputText'];

  // Read the contents of main.js file
  $filePath = 'js/main.js';
  $fileContents = file_get_contents($filePath);

  // Find the position to inject the received data
  $injectionPoint = strpos($fileContents, '];window.onload = () => {');

  if ($injectionPoint !== false) {
    // Construct the modified contents with the received data and a newline
    $modifiedContents = substr($fileContents, 0, $injectionPoint) . $outputText . "\n" . substr($fileContents, $injectionPoint);

    // Write the modified contents back to the main.js file
    file_put_contents($filePath, $modifiedContents);

    // Output success message
    echo "Data injected into main.js successfully!";
  } else {
    // Output error message if the injection point is not found
    echo "Error: Injection point not found in main.js!";
  }
} else {
  // Output error message if the outputText parameter is missing
  echo "Error: outputText parameter not found in the request!";
}
?>